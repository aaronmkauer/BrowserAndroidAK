package com.example.student.browser;

import android.graphics.Bitmap;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileWriter;
import java.io.File;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> history = new ArrayList<String>(0);
    public static void addToHistory(String str){
        history.add(str);
    }
    WebView webView;
    SwipeRefreshLayout swipe;

    public void createHistoryHTML(String input){
        String text = "<!DOCTYPE html>"+"<html><head><title>repl.it</title></head><body><h1>History</h1>";
        addToHistory(input);
        for(int x=0; x<history.size();x++){
            text=text+"<a href="+"\""+history.get(x)+"\""+">"+history.get(x)+"</a>";
            text=text+"<br>";
        }
        text=text+"</body>"+"</html>";
        BufferedWriter output = null;
        try {

            //File file = new File(cacheDir, "history.html");
            File file = new File(this.getCacheDir(), "history.html");
            //File file = new File("file:///android_asset/history.html");
            output = new BufferedWriter(new FileWriter(file));
            output.write(text);
            output.close();
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipe = (SwipeRefreshLayout)findViewById(R.id.swipe);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                WebAction();
            }
        });

        WebAction();
        final Button button = findViewById(R.id.button);
        final Button button2 = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                WebAction();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                webView = (WebView) findViewById(R.id.webView);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.getSettings().setAppCacheEnabled(true);
                //this.getCacheDir();
                //webView.loadUrl("file:///android_asset/history.html");
                File dir = new File(getCacheDir(), "history.html");
                Log.e("testAbsolute","file://" +dir.getAbsolutePath());
                webView.loadUrl("file://" +dir.getAbsolutePath());
                swipe.setRefreshing(true);
                webView.setWebViewClient(new WebViewClient(){


                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        //WebView webViewer = (WebView) findViewById(R.id.webView);
                        //webViewer.loadUrl("file:///android_asset/error.html");
                        //webView.loadUrl("file:///android_assets/error.html");

                    }

                    public void onPageFinished(WebView view, String url) {
                        // do your stuff here
                        swipe.setRefreshing(false);
                    }

                });
            }
        });

    }



public String currentUrl;
    /*
    private class MyWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            currentUrl=url;
            Log.e("WebView", "your current url when webpage loading.." + url);
        }

    }
    */

String currentURL;
    public void WebAction(){
        EditText editText = (EditText) findViewById(R.id.editText);
        //Button button = (Button) findViewById(R.id.button);
        webView = (WebView) findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAppCacheEnabled(true);
        String str= editText.getText().toString();
        str="https://www." + str;
        //webView.loadUrl("file:///android_asset/history.html");
        //createHistoryHTML(str);
        webView.loadUrl(str);
        //Log.e("current website",webView.getOriginalUrl());
        swipe.setRefreshing(true);



/*
        webView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                webView.onTouchEvent(event);


                if(currentUrl!=history.get(history.size()-1)){
                    createHistoryHTML(currentURL);
                }
                return true;
            }
        });

*/



        webView.setWebViewClient(new WebViewClient(){

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Log.e("WebView", "your current url when webpage loading.." + url);
                super.onPageStarted(view, url, favicon);
                //.e("WebView", "your current url when webpage loading.." + url);
                //if(history.size()==0){
                //    createHistoryHTML("https://www.google.com/");
                //}
                //else if(url!=history.get(history.size()-1)) {
                    createHistoryHTML(url);
                //}
                //Log.e("WebView", "your current url when webpage loading.." + url);
            }

            public void onPageFinished(WebView view, String url) {
                // do your stuff here
                swipe.setRefreshing(false);
            }

        });

    }


    @Override
    public void onBackPressed(){

        if (webView.canGoBack()){
            webView.goBack();
        }else {
            finish();
        }
    }
}